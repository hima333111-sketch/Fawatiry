package com.example.fawatiry
import android.app.*; import android.os.*; import android.content.*; import android.graphics.Color; import android.view.Gravity; import android.widget.*; import org.json.*

data class Inv(val client:String,val amount:Double,val paid:Double,val date:String)

class MainActivity:AppCompatActivity(){
 private val sp by lazy{getSharedPreferences("fawatiry",0)}
 private val clients=mutableListOf<String>(); private val invs=mutableListOf<Inv>()
 override fun onCreate(b:Bundle?){super.onCreate(b);load();home()}
 fun load(){clients.clear();invs.clear(); val c=JSONArray(sp.getString("clients","[]"));for(i in 0 until c.length())clients.add(c.getString(i))
  val a=JSONArray(sp.getString("invoices","[]"));for(i in 0 until a.length()){val o=a.getJSONObject(i);invs.add(Inv(o.getString("c"),o.getDouble("a"),o.getDouble("p"),o.getString("d")))}}
 fun save(){val c=JSONArray();clients.forEach{c.put(it)};val a=JSONArray();invs.forEach{a.put(JSONObject().put("c",it.client).put("a",it.amount).put("p",it.paid).put("d",it.date))};sp.edit().putString("clients",c.toString()).putString("invoices",a.toString()).apply()}
 fun base()=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(25,30,25,20)}
 fun lp()=LinearLayout.LayoutParams(-1,65).apply{setMargins(0,7,0,7)}
 fun bt(t:String,f:()->Unit)=Button(this).apply{text=t;textSize=17f;setOnClickListener{f()}}
 fun home(){val r=base();r.addView(TextView(this).apply{text="فواتيري";textSize=30f;gravity=17;setTextColor(Color.rgb(20,80,150));setPadding(0,10,0,25)})
  val sales=invs.sumOf{it.amount};val paid=invs.sumOf{it.paid}
  r.addView(TextView(this).apply{text="المبيعات: %.2f جنيه\nالمدفوع: %.2f جنيه\nالمتبقي: %.2f جنيه".format(sales,paid,sales-paid);textSize=18f;gravity=17})
  r.addView(bt("👤 العملاء"){clientsPage()},lp());r.addView(bt("🧾 فاتورة جديدة"){invoicePage()},lp());r.addView(bt("📒 كشف حساب عميل"){statementPage()},lp())
  r.addView(bt("📤 مشاركة ملخص الحساب"){shareSummary()},lp())
  r.addView(bt("ℹ️ عن فواتيري"){about()},lp());setContentView(r)}
 fun clientsPage(){val r=base();r.addView(TextView(this).apply{text="العملاء";textSize=25f;gravity=17})
  val e=EditText(this).apply{hint="اسم العميل";textSize=18f};r.addView(e,lp());r.addView(bt("➕ إضافة"){val n=e.text.toString().trim();if(n.isNotEmpty()){clients.add(n);save();clientsPage()}else Toast.makeText(this,"اكتب اسم العميل",0).show()},lp())
  r.addView(TextView(this).apply{text=if(clients.isEmpty())"لا يوجد عملاء" else clients.mapIndexed{i,n->"${i+1} - $n"}.joinToString("\n");textSize=18f;setPadding(5,15,5,15)});r.addView(bt("رجوع"){home()},lp());setContentView(r)}
 fun invoicePage(){val r=base();r.addView(TextView(this).apply{text="فاتورة جديدة";textSize=25f;gravity=17})
  val c=EditText(this).apply{hint="اسم العميل"};val a=EditText(this).apply{hint="قيمة الفاتورة";inputType=2};val p=EditText(this).apply{hint="المدفوع";inputType=2}
  r.addView(c,lp());r.addView(a,lp());r.addView(p,lp());r.addView(bt("💾 حفظ"){val av=a.text.toString().toDoubleOrNull();val pv=p.text.toString().toDoubleOrNull()?:0.0;val cn=c.text.toString().trim()
   if(cn.isEmpty()||av==null||av<=0)Toast.makeText(this,"أدخل اسم العميل وقيمة صحيحة",0).show() else{if(!clients.contains(cn))clients.add(cn);invs.add(Inv(cn,av,pv.coerceIn(0.0,av),java.text.SimpleDateFormat("yyyy/MM/dd",java.util.Locale.getDefault()).format(java.util.Date())));save();home()}},lp());r.addView(bt("رجوع"){home()},lp());setContentView(r)}
 fun statementPage(){val r=base();r.addView(TextView(this).apply{text="كشف حساب";textSize=25f;gravity=17})
  if(clients.isEmpty()){r.addView(TextView(this).apply{text="لا يوجد عملاء حتى الآن";textSize=18f;gravity=17},lp());r.addView(bt("رجوع"){home()},lp());setContentView(r);return}
  val spn=Spinner(this);spn.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,clients);r.addView(spn,lp())
  val out=TextView(this).apply{textSize=17f;setPadding(5,12,5,12)};r.addView(out,LinearLayout.LayoutParams(-1,0,1f))
  val pay=EditText(this).apply{hint="مبلغ دفعة جديدة";inputType=2;textSize=17f};r.addView(pay,lp())
  r.addView(bt("💵 تسجيل دفعة"){val n=spn.selectedItem.toString();val amount=pay.text.toString().toDoubleOrNull()
    if(amount==null||amount<=0)Toast.makeText(this,"اكتب مبلغ صحيح",0).show()
    else{var left=amount;for(i in invs.indices){val v=invs[i];if(v.client==n && v.paid<v.amount){val add=minOf(left,v.amount-v.paid);invs[i]=v.copy(paid=v.paid+add);left-=add;if(left<=0)break}}
      save();pay.text.clear();showStatement(out,n)}},lp())
  r.addView(bt("🗑️ حذف فواتير العميل"){val n=spn.selectedItem.toString()
    AlertDialog.Builder(this).setTitle("تأكيد الحذف").setMessage("حذف كل فواتير $n ؟").setNegativeButton("إلغاء",null).setPositiveButton("حذف"){_,_->invs.removeAll{it.client==n};save();showStatement(out,n)}.show()},lp())
  r.addView(bt("رجوع"){home()},lp());setContentView(r)
  fun refresh(){showStatement(out,spn.selectedItem.toString())}
  spn.onItemSelectedListener=object:android.widget.AdapterView.OnItemSelectedListener{
    override fun onNothingSelected(p:android.widget.AdapterView<*>?){}
    override fun onItemSelected(p:android.widget.AdapterView<*>?,v:android.view.View?,pos:Int,id:Long){refresh()}
  }
  refresh()
 }
 private fun showStatement(out:TextView,n:String){val x=invs.filter{it.client==n}
  out.text=if(x.isEmpty())"العميل: $n\n\nلا توجد فواتير" else "العميل: $n\n\n"+
    x.mapIndexed{i,v->"فاتورة ${i+1} — ${v.date}\nالقيمة: ${"%.2f".format(v.amount)} جنيه\nالمدفوع: ${"%.2f".format(v.paid)} جنيه\nالمتبقي: ${"%.2f".format(v.amount-v.paid)} جنيه"}.joinToString("\n\n")+
    "\n\nالإجمالي: %.2f جنيه\nالمدفوع: %.2f جنيه\nالمتبقي: %.2f جنيه".format(x.sumOf{it.amount},x.sumOf{it.paid},x.sumOf{it.amount-it.paid})
 }
 private fun shareSummary(){
  val sales=invs.sumOf{it.amount}; val paid=invs.sumOf{it.paid}; val due=sales-paid
  val text="فواتيري\n\nإجمالي المبيعات: %.2f جنيه\nإجمالي المدفوع: %.2f جنيه\nإجمالي المتبقي: %.2f جنيه".format(sales,paid,due)
  val i=Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_TEXT,text)}
  startActivity(Intent.createChooser(i,"مشاركة ملخص الحساب"))
 }
 private fun about(){
  AlertDialog.Builder(this).setTitle("فواتيري")
   .setMessage("دفتر فواتير وحسابات بسيط بالعربي.\n\nالإصدار 1.3\nالبيانات محفوظة على الجهاز.")
   .setPositiveButton("تمام",null).show()
 }

}
