plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace="com.example.fawatiry"; compileSdk=35
 defaultConfig { applicationId="com.example.fawatiry"; minSdk=23; targetSdk=35; versionCode=3; versionName="1.2" }
}
dependencies {
 implementation("androidx.core:core-ktx:1.15.0")
 implementation("androidx.appcompat:appcompat:1.7.0")
 implementation("com.google.android.material:material:1.12.0")
 implementation("androidx.activity:activity-ktx:1.10.0")
}